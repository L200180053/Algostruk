#No 8
def apakahTerkandung(x, y):
    for k in x:
        if k in y:
            return True
        else:
            return False
