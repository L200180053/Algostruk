#No 4
def rerata(b):
    k = 0
    for i in (b):
        k+=i
    hasil = k / len(b)
    return hasil
