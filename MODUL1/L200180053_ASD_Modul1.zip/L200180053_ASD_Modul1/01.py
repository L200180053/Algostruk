#No 1
x = int(input("Masukkan angka:"))
def cetakSiku2():
 for i in range (0, x):
    i+=1
    print ("*" * i)
    
cetakSiku2()
